//
//  LogoutResponse.swift
//  OnTheMap
//
//  Created by Rahaf Naif on 26/10/1441 AH.
//  Copyright © 1441 Rahaf Naif. All rights reserved.
//

import Foundation

struct LogoutResponse : Codable {
    let session : Session
}

